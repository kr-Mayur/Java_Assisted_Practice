package com.ecommerce.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.servlet.ModelAndView;

import com.ecommerce.entity.EProductEntity;
import com.ecommerce.service.EProductService;

@Controller
public class EProductController {

        @Autowired
             EProductService eproductService;
        @RequestMapping(value="ProductList",method = RequestMethod.GET)
    	public ModelAndView ProductList() {
    		
    		List<EProductEntity> listOfProduct=eproductService.getAllProducts();
    		ModelAndView mav=new ModelAndView();
    		mav.addObject("listOfProduct",listOfProduct);
    		mav.setViewName("productList.jsp");
    		return mav;
    		
    	}

}
